import tkinter as tk
from tkinter import filedialog
import random
import json
import os
import math

MODEL_FILE = "iris.bot"
MAX_LEN = 12
NUM_HEADS = 4
NUM_LAYERS = 2
DEFAULT_D_MODEL = 32
FF_MULTIPLIER = 2
LEARNING_RATE = 0.01
MEMORY_WINDOW = 4

if not os.path.exists("vocab.txt"):
    with open("vocab.txt","w") as f:
        f.write("I\nfeel\nthink\nknow\nlike\nsee\nunderstand\nworld\nlife\nhuman\nfuture\nmemory\nemotion\nlogic\nenergy\ncreate\nlearn\nobserve\nsystem\nmind")

with open("vocab.txt") as f:
    vocab = [w.strip() for w in f.readlines() if w.strip()]

vocab_size = len(vocab)

d_model = DEFAULT_D_MODEL
head_dim = d_model // NUM_HEADS
ff_dim = d_model * FF_MULTIPLIER

embeddings = []
blocks = []
W_out = []

conversation_memory = []
emotion_vector = [0.0]*DEFAULT_D_MODEL
last_hidden = []
last_attention = []
brain_activity = []

def rand_matrix(r,c):
    return [[random.uniform(-0.5,0.5) for _ in range(c)] for _ in range(r)]

def initialize_model():
    global embeddings, blocks, W_out
    global head_dim, ff_dim

    head_dim = d_model // NUM_HEADS
    ff_dim = d_model * FF_MULTIPLIER

    embeddings = rand_matrix(vocab_size,d_model)

    blocks.clear()
    for _ in range(NUM_LAYERS):
        block = {
            "Wq":[rand_matrix(d_model,head_dim) for _ in range(NUM_HEADS)],
            "Wk":[rand_matrix(d_model,head_dim) for _ in range(NUM_HEADS)],
            "Wv":[rand_matrix(d_model,head_dim) for _ in range(NUM_HEADS)],
            "Wo":rand_matrix(d_model,d_model),
            "W1":rand_matrix(d_model,ff_dim),
            "W2":rand_matrix(ff_dim,d_model)
        }
        blocks.append(block)

    W_out = rand_matrix(d_model,vocab_size)

def softmax(v):
    m=max(v)
    ex=[math.exp(x-m) for x in v]
    s=sum(ex)
    return [x/s for x in ex]

def matmul(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def add(a,b):
    return [[x+y for x,y in zip(r1,r2)] for r1,r2 in zip(a,b)]

def relu(m):
    return [[max(0,x) for x in row] for row in m]

def layer_norm(X):
    out=[]
    for row in X:
        mean=sum(row)/len(row)
        var=sum((x-mean)**2 for x in row)/len(row)
        norm=[(x-mean)/math.sqrt(var+1e-6) for x in row]
        out.append(norm)
    return out

def positional_encoding(length):
    pe=[]
    for pos in range(length):
        row=[]
        for i in range(d_model):
            angle=pos/(10000**(2*(i//2)/d_model))
            row.append(math.sin(angle) if i%2==0 else math.cos(angle))
        pe.append(row)
    return pe

def multi_head_attention(X,block):
    global last_attention
    heads=[]

    for h in range(NUM_HEADS):
        Q=matmul(X,block["Wq"][h])
        K=matmul(X,block["Wk"][h])
        V=matmul(X,block["Wv"][h])

        scores=[]
        for q in Q:
            row=[]
            for k in K:
                row.append(sum(qi*ki for qi,ki in zip(q,k))/math.sqrt(head_dim))
            row=softmax(row)
            scores.append(row)

        if h==0:
            last_attention=scores

        context=[]
        for s in scores:
            vec=[0]*head_dim
            for weight,v in zip(s,V):
                for i in range(head_dim):
                    vec[i]+=weight*v[i]
            context.append(vec)

        heads.append(context)

    concat=[]
    for i in range(len(X)):
        combined=[]
        for h in range(NUM_HEADS):
            combined+=heads[h][i]
        concat.append(combined)

    return matmul(concat,block["Wo"])

def transformer(ids):
    X=[embeddings[i] for i in ids]
    X=add(X,positional_encoding(len(X)))

    for block in blocks:
        attn=multi_head_attention(X,block)
        X=layer_norm(add(X,attn))

        ff=relu(matmul(X,block["W1"]))
        ff=matmul(ff,block["W2"])
        X=layer_norm(add(X,ff))

    return X

def train_output(hidden,target):
    global W_out
    logits=[sum(hidden[j]*W_out[j][i] for j in range(d_model)) for i in range(vocab_size)]
    probs=softmax(logits)

    for i in range(vocab_size):
        error=(1 if i==target else 0)-probs[i]
        for j in range(d_model):
            W_out[j][i]+=LEARNING_RATE*error*hidden[j]

def tokenize(text):
    ids=[]
    for w in text.split():
        if w in vocab:
            ids.append(vocab.index(w))
        else:
            ids.append(random.randint(0,vocab_size-1))
    return ids[:MAX_LEN] if ids else [random.randint(0,vocab_size-1)]

def generate(user_input):
    global last_hidden, brain_activity, conversation_memory

    conversation_memory.append(user_input)
    if len(conversation_memory)>MEMORY_WINDOW:
        conversation_memory.pop(0)

    full_context=" ".join(conversation_memory)
    ids=tokenize(full_context)

    X=transformer(ids)
    final=X[-1]

    conditioned=[final[i]+emotion_vector[i] for i in range(d_model)]

    logits=[sum(conditioned[j]*W_out[j][i] for j in range(d_model)) for i in range(vocab_size)]
    probs=softmax(logits)

    sorted_indices=sorted(range(len(probs)),key=lambda i:probs[i],reverse=True)
    words=[]
    used=set()

    for idx in sorted_indices:
        word=vocab[idx]
        if word not in used:
            words.append(word)
            used.add(word)
        if len(words)>=random.randint(5,10):
            break

    sentence=" ".join(words).capitalize()+"."

    target=random.randint(0,vocab_size-1)
    train_output(conditioned,target)

    last_hidden=conditioned
    brain_activity=conditioned[:50]

    return sentence

def train_dataset():
    file=filedialog.askopenfilename()
    if not file:
        return
    with open(file) as f:
        for line in f:
            ids=tokenize(line.strip())
            X=transformer(ids)
            train_output(X[-1],random.randint(0,vocab_size-1))

def draw_heatmap():
    heat.delete("all")
    size=len(last_attention)
    cell=20
    for i in range(size):
        for j in range(size):
            v=last_attention[i][j]
            c=int(v*255)
            heat.create_rectangle(j*cell,i*cell+1,j*cell+cell,i*cell+cell,fill=f'#{c:02x}{c:02x}00')

def draw_brain():
    brain.delete("all")
    w=300
    h=150
    for i,val in enumerate(brain_activity):
        x=i*6
        y=h/2
        brain.create_line(x,y,x,y-val*50)

def send():
    text=entry.get().strip()
    if not text:
        return
    response=generate(text)
    chat.insert(tk.END,"You: "+text+"\n")
    chat.insert(tk.END,"IRIS: "+response+"\n\n")
    entry.delete(0,tk.END)
    draw_heatmap()
    draw_brain()

root=tk.Tk()
root.title("IRIS 1.1")

chat=tk.Text(root,height=16,width=90)
chat.pack()

entry=tk.Entry(root,width=70)
entry.pack()

tk.Button(root,text="Send",command=send).pack()
tk.Button(root,text="Train Dataset",command=train_dataset).pack()

heat=tk.Canvas(root,width=250,height=250,bg="black")
heat.pack()

brain=tk.Canvas(root,width=300,height=150,bg="white")
brain.pack()

initialize_model()
root.mainloop()