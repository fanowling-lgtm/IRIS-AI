import tkinter as tk
import random
import math
import json
import os

D_MODEL = 32
MEMORY_FILE = "memory_vectors.json"
MODULES = ["language","emotion","memory","logic"]

if not os.path.exists("vocab.txt"):
    with open("vocab.txt","w") as f:
        f.write("I\nfeel\nthink\nknow\nlike\nsee\nunderstand\nworld\nlife\nhuman\nfuture\nmemory\nemotion\nlogic\nenergy\ncreate\nlearn\nobserve\nsystem\nmind\nhappy\nsad\nangry\ncurious")

with open("vocab.txt") as f:
    vocab=[w.strip() for w in f.readlines() if w.strip()]

vocab_size=len(vocab)

def rand_matrix(r,c):
    return [[random.uniform(-0.5,0.5) for _ in range(c)] for _ in range(r)]

def softmax(v):
    m=max(v)
    ex=[math.exp(x-m) for x in v]
    s=sum(ex)
    return [x/s for x in ex]

def magnitude(v):
    return sum(abs(x) for x in v)/len(v)

if not os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE,"w") as f:
        json.dump([],f)

def load_memory():
    with open(MEMORY_FILE) as f:
        return json.load(f)

def save_memory(mem):
    with open(MEMORY_FILE,"w") as f:
        json.dump(mem,f)

class ModuleAI:
    def __init__(self,name):
        self.name=name
        self.emb=rand_matrix(vocab_size,D_MODEL)
        self.W1=rand_matrix(D_MODEL,D_MODEL)
        self.W2=rand_matrix(D_MODEL,D_MODEL)

        self.dataset_file=f"{name}_dataset.json"
        if not os.path.exists(self.dataset_file):
            with open(self.dataset_file,"w") as f:
                json.dump([],f)

    def forward(self,ids):
        vec=[0]*D_MODEL
        for i in ids:
            for j in range(D_MODEL):
                vec[j]+=self.emb[i][j]

        h=[sum(vec[j]*self.W1[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]
        o=[sum(h[j]*self.W2[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]
        return o

    def generate_sentence(self,vec):
        W_out=rand_matrix(D_MODEL,vocab_size)
        logits=[sum(vec[j]*W_out[j][i] for j in range(D_MODEL)) for i in range(vocab_size)]
        probs=softmax(logits)

        sorted_indices=sorted(range(len(probs)),key=lambda i:probs[i],reverse=True)

        words=[]
        used=set()
        for idx in sorted_indices:
            w=vocab[idx]
            if w not in used:
                words.append(w)
                used.add(w)
            if len(words)>=random.randint(5,9):
                break

        return " ".join(words).capitalize()+"."

    def train_on_dataset(self):
        with open(self.dataset_file) as f:
            data=json.load(f)

        for text in data:
            ids=tokenize(text)
            vec=self.forward(ids)

            for i in range(D_MODEL):
                self.W1[i][i]+=0.0001*vec[i]

    def mutate(self):
        for i in range(D_MODEL):
            for j in range(D_MODEL):
                if random.random()<0.001:
                    self.W1[i][j]+=random.uniform(-0.05,0.05)

LanguageAI=ModuleAI("language")
EmotionAI=ModuleAI("emotion")
MemoryAI=ModuleAI("memory")
LogicAI=ModuleAI("logic")

def tokenize(text):
    ids=[]
    for w in text.split():
        if w in vocab:
            ids.append(vocab.index(w))
    return ids if ids else [random.randint(0,vocab_size-1)]

def self_reflection(response):
    score=len(response.split())
    return score

def debate(input_text):
    ids=tokenize(input_text)

    modules=[LanguageAI,EmotionAI,MemoryAI,LogicAI]
    results=[]

    long_memory=load_memory()

    for mod in modules:
        vec=mod.forward(ids)

        for mem_vec in long_memory:
            for i in range(D_MODEL):
                vec[i]+=mem_vec[i]*0.1

        sentence=mod.generate_sentence(vec)
        confidence=magnitude(vec)

        results.append((mod.name,sentence,confidence))

    results.sort(key=lambda x:x[2],reverse=True)

    winner=results[0]

    reflection_score=self_reflection(winner[1])

    long_memory.append(modules[0].forward(ids))
    if len(long_memory)>20:
        long_memory.pop(0)
    save_memory(long_memory)

    for mod in modules:
        mod.mutate()

    return winner[1], results

def send():
    user_input=entry.get().strip()
    if not user_input:
        return

    response,all_results=debate(user_input)

    chat.insert(tk.END,"You: "+user_input+"\n")

    for name,sent,conf in all_results:
        chat.insert(tk.END,f"[{name.upper()}] {sent} (conf:{round(conf,2)})\n")

    chat.insert(tk.END,"\nFINAL: "+response+"\n\n")

    entry.delete(0,tk.END)

root=tk.Tk()
root.title("IRIS 1.3")

chat=tk.Text(root,height=20,width=100)
chat.pack()

entry=tk.Entry(root,width=80)
entry.pack()

tk.Button(root,text="Send",command=send).pack()

root.mainloop()