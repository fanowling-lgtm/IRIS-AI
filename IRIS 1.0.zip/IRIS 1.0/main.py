import tkinter as tk
from tkinter import filedialog
import random
import json
import os
import math

if not os.path.exists("vocab.txt"):
    with open("vocab.txt", "w") as f:
        f.write("I\nfeel\nthink\nknow\nlike\nsee\nunderstand\nworld\nlife\nhuman\nfuture\nmemory\nemotion\nlogic\nenergy\ncreate\nlearn\nobserve\nsystem\nmind")

def load_vocab():
    with open("vocab.txt") as f:
        return [w.strip() for w in f.readlines() if w.strip()]

vocab = load_vocab()

brain = {
    "input_size": 8,
    "hidden_size": 12,
    "output_size": len(vocab),
    "emotion": 0.0,
    "W1": [],
    "W2": [],
    "last_hidden": [],
    "last_output_index": 0
}

def initialize_network():
    brain["W1"] = [
        [random.uniform(-1,1) for _ in range(brain["hidden_size"])]
        for _ in range(brain["input_size"])
    ]

    brain["W2"] = [
        [random.uniform(-1,1) for _ in range(brain["output_size"])]
        for _ in range(brain["hidden_size"])
    ]

initialize_network()

def set_intelligence(val):
    size = int(val)
    brain["hidden_size"] = size
    initialize_network()
    draw_network()

def text_features(text):
    features = [
        len(text)/50,
        text.count("!"),
        text.count("?"),
        sum(c.isupper() for c in text)/20,
        len(text.split())/10,
        brain["emotion"],
        random.random(),
        1.0
    ]
    return features

def forward_pass(user_input):
    x = text_features(user_input)

    hidden = []
    for j in range(brain["hidden_size"]):
        total = 0
        for i in range(brain["input_size"]):
            total += x[i] * brain["W1"][i][j]
        hidden.append(math.tanh(total))

    outputs = []
    for k in range(brain["output_size"]):
        total = 0
        for j in range(brain["hidden_size"]):
            total += hidden[j] * brain["W2"][j][k]
        outputs.append(total)

    index = outputs.index(max(outputs))

    brain["last_hidden"] = hidden
    brain["last_output_index"] = index

    brain["emotion"] = sum(hidden)/len(hidden)

    hebbian_update(x, hidden)

    return vocab[index]

def hebbian_update(x, hidden):
    lr = 0.01
    for i in range(brain["input_size"]):
        for j in range(brain["hidden_size"]):
            brain["W1"][i][j] += lr * x[i] * hidden[j]

def reinforce_positive():
    lr = 0.05
    idx = brain["last_output_index"]
    for j in range(brain["hidden_size"]):
        brain["W2"][j][idx] += lr * brain["last_hidden"][j]

def reinforce_negative():
    lr = 0.05
    idx = brain["last_output_index"]
    for j in range(brain["hidden_size"]):
        brain["W2"][j][idx] -= lr * brain["last_hidden"][j]

def generate_sentence(user_input):
    words = []
    length = random.randint(5,10)

    for _ in range(length):
        word = forward_pass(user_input)
        words.append(word)

    sentence = " ".join(words)
    sentence = sentence.capitalize()

    if sentence[-1] not in ".!?":
        sentence += "."

    return sentence

def export_creature():
    file_path = filedialog.asksaveasfilename(defaultextension=".bot")
    if not file_path:
        return
    with open(file_path, "w") as f:
        json.dump(brain, f)

def import_creature():
    file_path = filedialog.askopenfilename(filetypes=[("Bot files","*.bot")])
    if not file_path:
        return
    with open(file_path) as f:
        data = json.load(f)
        brain.update(data)
    draw_network()

def draw_network():
    canvas.delete("all")

    input_y = 80
    hidden_y = 200
    output_y = 340

    input_xs = [100 + i*50 for i in range(brain["input_size"])]
    hidden_xs = [100 + i*40 for i in range(brain["hidden_size"])]
    output_xs = [100 + i*15 for i in range(min(20, brain["output_size"]))]

    for i in range(brain["input_size"]):
        for j in range(brain["hidden_size"]):
            w = brain["W1"][i][j]
            if abs(w) > 0.5:
                intensity = int(min(abs(w)*255,255))
                color = f'#{intensity:02x}0000' if w>0 else f'#0000{intensity:02x}'
                canvas.create_line(input_xs[i],input_y,hidden_xs[j],hidden_y,fill=color)

    for x in input_xs:
        canvas.create_oval(x-10,input_y-10,x+10,input_y+10,fill="white")

    for x in hidden_xs:
        canvas.create_oval(x-12,hidden_y-12,x+12,hidden_y+12,fill="green")

    for x in output_xs:
        canvas.create_oval(x-6,output_y-6,x+6,output_y+6,fill="yellow")

def send():
    user_input = entry.get().strip()
    if not user_input:
        return

    response = generate_sentence(user_input)

    chat.insert(tk.END, "You: " + user_input + "\n")
    chat.insert(tk.END, "IRIS: " + response + "\n\n")

    entry.delete(0, tk.END)
    draw_network()

root = tk.Tk()
root.title("IRIS 1.0")

chat = tk.Text(root, height=15, width=80)
chat.pack()

entry = tk.Entry(root, width=60)
entry.pack()

send_btn = tk.Button(root, text="Send", command=send)
send_btn.pack()

slider = tk.Scale(root, from_=4, to=40, orient="horizontal",
                  label="Intelligence (Hidden Neurons)",
                  command=set_intelligence)
slider.set(12)
slider.pack()

tk.Button(root, text="Encourage", command=reinforce_positive).pack()
tk.Button(root, text="Discourage", command=reinforce_negative).pack()

tk.Button(root, text="Export", command=export_creature).pack()
tk.Button(root, text="Import", command=import_creature).pack()

canvas = tk.Canvas(root, width=800, height=400, bg="black")
canvas.pack()

root.bind("<Return>", lambda event: send())

draw_network()

root.mainloop()

