import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import random
import json
import os
import tkinter as tk
from tkinter import filedialog
import matplotlib.pyplot as plt

device = torch.device("cpu")

class Tokenizer:
    def __init__(self, vocab_file="vocab.txt"):
        self.vocab_file = vocab_file
        self.vocab = ["<PAD>", "<UNK>"]
        if os.path.exists(vocab_file):
            with open(vocab_file, "r") as f:
                self.vocab += [w.strip() for w in f.readlines()]
        self.word2idx = {w:i for i,w in enumerate(self.vocab)}
        self.idx2word = {i:w for i,w in enumerate(self.vocab)}

    def encode(self, text):
        tokens = text.lower().split()
        ids = []
        for t in tokens:
            if t not in self.word2idx:
                self.add_word(t)
            ids.append(self.word2idx.get(t,1))
        return ids

    def decode(self, ids):
        return " ".join([self.idx2word.get(i,"?") for i in ids])

    def add_word(self, word):
        if word not in self.word2idx:
            self.word2idx[word] = len(self.vocab)
            self.idx2word[len(self.vocab)] = word
            self.vocab.append(word)
            with open(self.vocab_file,"a") as f:
                f.write(word+"\n")

tokenizer = Tokenizer()

class TransformerBlock(nn.Module):
    def __init__(self, dim, heads):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim*4),
            nn.ReLU(),
            nn.Linear(dim*4, dim)
        )
        self.norm2 = nn.LayerNorm(dim)

    def forward(self, x):
        attn_output,_ = self.attn(x,x,x)
        x = self.norm1(x + attn_output)
        ff_out = self.ff(x)
        x = self.norm2(x + ff_out)
        return x


class ModuleBrain(nn.Module):
    def __init__(self, vocab_size, dim=64, heads=4, layers=2):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, dim)
        self.blocks = nn.ModuleList([
            TransformerBlock(dim, heads) for _ in range(layers)
        ])
        self.output = nn.Linear(dim, vocab_size)

    def forward(self, x):
        x = self.embedding(x)
        for block in self.blocks:
            x = block(x)
        logits = self.output(x)
        return logits

class IrisCreature:
    def __init__(self):
        self.modules = []
        self.genome = []
        self.memory_vectors = []
        self.topic_memory = []
        self.module_weights = []

        self.create_modules()

    def create_modules(self):
        for i in range(3):
            m = ModuleBrain(len(tokenizer.vocab))
            self.modules.append(m)
            self.module_weights.append(random.random())
            self.genome.append(random.random())

    def respond(self, text):
        tokens = tokenizer.encode(text)
        x = torch.tensor([tokens], dtype=torch.long)

        outputs = []
        for m in self.modules:
            logits = m(x)
            probs = F.softmax(logits[0,-1], dim=0)
            word = torch.multinomial(probs,1).item()
            outputs.append(word)

        # debate
        chosen = random.choices(outputs, weights=self.module_weights)[0]

        self.memory_vectors.append(chosen)
        if len(self.memory_vectors)>50:
            self.memory_vectors.pop(0)

        return tokenizer.decode([chosen])

    def train_step(self, text):
        tokens = tokenizer.encode(text)
        if len(tokens)<2:
            return

        x = torch.tensor([tokens[:-1]])
        y = torch.tensor([tokens[1:]])

        for m in self.modules:
            opt = torch.optim.Adam(m.parameters(), lr=0.001)
            logits = m(x)
            loss = F.cross_entropy(
                logits.view(-1, logits.size(-1)),
                y.view(-1)
            )
            opt.zero_grad()
            loss.backward()
            opt.step()

    def mutate(self):
        for i in range(len(self.module_weights)):
            self.module_weights[i] += random.uniform(-0.1,0.1)

    def crossover(self):
        if len(self.modules)<2: return
        self.module_weights[0], self.module_weights[1] = \
            self.module_weights[1], self.module_weights[0]

    def save(self, path):
        data = {
            "weights": self.module_weights,
            "genome": self.genome
        }
        torch.save(data, path)

    def load(self, path):
        data = torch.load(path)
        self.module_weights = data["weights"]
        self.genome = data["genome"]

iris = IrisCreature()


root = tk.Tk()
root.title("IRIS 1.4")

chat = tk.Text(root, height=20)
chat.pack()

entry = tk.Entry(root)
entry.pack()

def send():
    user = entry.get()
    chat.insert(tk.END, "You: "+user+"\n")
    reply = iris.respond(user)
    chat.insert(tk.END, "IRIS: "+reply+"\n")
    entry.delete(0, tk.END)

def train():
    iris.train_step(entry.get())

def mutate():
    iris.mutate()

def crossover():
    iris.crossover()

def save():
    path = filedialog.asksaveasfilename(defaultextension=".bot")
    if path:
        iris.save(path)

def load():
    path = filedialog.askopenfilename()
    if path:
        iris.load(path)

tk.Button(root,text="Send",command=send).pack()
tk.Button(root,text="Train",command=train).pack()
tk.Button(root,text="Mutate",command=mutate).pack()
tk.Button(root,text="Crossover",command=crossover).pack()
tk.Button(root,text="Save",command=save).pack()
tk.Button(root,text="Load",command=load).pack()

root.mainloop()