import tkinter as tk
from tkinter import filedialog
import random
import json
import os
import math

D_MODEL = 32
MEMORY_WINDOW = 4
MODEL_FILE = "iris.bot"

if not os.path.exists("vocab.txt"):
    with open("vocab.txt","w") as f:
        f.write("I\nfeel\nthink\nknow\nlike\nsee\nunderstand\nworld\nlife\nhuman\nfuture\nmemory\nemotion\nlogic\nenergy\ncreate\nlearn\nobserve\nsystem\nmind\nhappy\nsad\nangry\ncurious")

with open("vocab.txt") as f:
    vocab=[w.strip() for w in f.readlines() if w.strip()]

vocab_size=len(vocab)

def rand_matrix(r,c):
    return [[random.uniform(-0.5,0.5) for _ in range(c)] for _ in range(r)]

def softmax(v):
    m=max(v)
    ex=[math.exp(x-m) for x in v]
    s=sum(ex)
    return [x/s for x in ex]

def magnitude(v):
    return sum(abs(x) for x in v)/len(v)

embeddings=rand_matrix(vocab_size,D_MODEL)
W_lang=rand_matrix(D_MODEL,D_MODEL)
W_emotion=rand_matrix(D_MODEL,D_MODEL)
W_memory=rand_matrix(D_MODEL,D_MODEL)
W_logic=rand_matrix(D_MODEL,D_MODEL)
W_out=rand_matrix(D_MODEL,vocab_size)

conversation_memory=[]
emotion_state=[0.0]*D_MODEL

personality={
    "lang_weight":1.0,
    "emo_weight":1.0,
    "mem_weight":1.0,
    "logic_weight":1.0,
    "emotion_bias":0.0
}

brain_activity={"lang":0,"emo":0,"mem":0,"logic":0}

def tokenize(text):
    ids=[]
    for w in text.split():
        if w in vocab:
            ids.append(vocab.index(w))
    return ids if ids else [random.randint(0,vocab_size-1)]

def language_network(ids):
    vec=[0]*D_MODEL
    for i in ids:
        for j in range(D_MODEL):
            vec[j]+=embeddings[i][j]
    return [sum(vec[j]*W_lang[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]

def emotion_network(vec):
    global emotion_state
    out=[sum(vec[j]*W_emotion[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]
    emotion_state=[emotion_state[i]*0.9+out[i]*0.1 for i in range(D_MODEL)]
    return emotion_state

def memory_network():
    mem=[0]*D_MODEL
    for text in conversation_memory:
        ids=tokenize(text)
        vec=language_network(ids)
        for i in range(D_MODEL):
            mem[i]+=vec[i]
    return [sum(mem[j]*W_memory[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]

def logic_network(vec):
    return [sum(vec[j]*W_logic[j][i] for j in range(D_MODEL)) for i in range(D_MODEL)]

def dynamic_fusion(lang,emo,mem,logic):

    w_lang=personality["lang_weight"]
    w_emo=personality["emo_weight"]+abs(magnitude(emo))*0.5
    w_mem=personality["mem_weight"]+len(conversation_memory)*0.1
    w_logic=personality["logic_weight"]

    brain_activity["lang"]=magnitude(lang)
    brain_activity["emo"]=magnitude(emo)
    brain_activity["mem"]=magnitude(mem)
    brain_activity["logic"]=magnitude(logic)

    final=[]
    for i in range(D_MODEL):
        value=(lang[i]*w_lang +
               emo[i]*w_emo +
               mem[i]*w_mem +
               logic[i]*w_logic)
        final.append(value)

    return final

def generate(text):
    conversation_memory.append(text)
    if len(conversation_memory)>MEMORY_WINDOW:
        conversation_memory.pop(0)

    ids=tokenize(text)

    lang=language_network(ids)
    emo=emotion_network(lang)
    mem=memory_network()
    logic=logic_network(lang)

    final=dynamic_fusion(lang,emo,mem,logic)

    logits=[sum(final[j]*W_out[j][i] for j in range(D_MODEL)) for i in range(vocab_size)]
    probs=softmax(logits)

    sorted_indices=sorted(range(len(probs)),key=lambda i:probs[i],reverse=True)

    words=[]
    used=set()
    for idx in sorted_indices:
        w=vocab[idx]
        if w not in used:
            words.append(w)
            used.add(w)
        if len(words)>=random.randint(5,9):
            break

    return " ".join(words).capitalize()+"."

def save_personality():
    file=filedialog.asksaveasfilename(defaultextension=".bot")
    if file:
        with open(file,"w") as f:
            json.dump(personality,f,indent=2)

def load_personality():
    file=filedialog.askopenfilename()
    if file:
        with open(file) as f:
            data=json.load(f)
        personality.update(data)

def draw_brain_map():
    canvas.delete("all")
    width=300
    height=200
    keys=["lang","emo","mem","logic"]

    for i,key in enumerate(keys):
        val=brain_activity[key]*100
        canvas.create_rectangle(20,20+i*40,20+val,50+i*40,fill="green")
        canvas.create_text(10,35+i*40,text=key,anchor="e")

def send():
    user_input=entry.get().strip()
    if not user_input:
        return
    response=generate(user_input)
    chat.insert(tk.END,"You: "+user_input+"\n")
    chat.insert(tk.END,"IRIS: "+response+"\n\n")
    entry.delete(0,tk.END)
    draw_brain_map()

root=tk.Tk()
root.title("IRIS 1.2")

chat=tk.Text(root,height=15,width=80)
chat.pack()

entry=tk.Entry(root,width=70)
entry.pack()

tk.Button(root,text="Send",command=send).pack()
tk.Button(root,text="Export",command=save_personality).pack()
tk.Button(root,text="Import",command=load_personality).pack()

canvas=tk.Canvas(root,width=350,height=200,bg="black")
canvas.pack()

root.mainloop()